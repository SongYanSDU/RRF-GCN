import tensorflow as tf


def cov_covariance_loss(conv1, conv2):
    # 提取卷积层的权重
    w1 = conv1.kernel
    w2 = conv2.kernel
    # 将权重展平
    w1_flat = tf.reshape(w1, [-1])
    w2_flat = tf.reshape(w2, [-1])
    # 计算均值
    mean_w1 = tf.reduce_mean(w1_flat)
    mean_w2 = tf.reduce_mean(w2_flat)
    # 计算协方差
    cov = tf.reduce_mean((w1_flat - mean_w1) * (w2_flat - mean_w2))
    return cov

# 假设 conv1 和 conv2 是两个模型的最后一层
# model1 = ...
# model2 = ...

# 在模型编译时添加协方差损失
# model1.add_loss(lambda: covariance_loss(model1.layers[-1], model2.layers[-1]))
# model2.add_loss(lambda: covariance_loss(model1.layers[-1], model2.layers[-1]))
