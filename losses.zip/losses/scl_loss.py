import tensorflow as tf
from tensorflow.keras import backend as K


alpha = 1.0  # loss weight
T = 1.0  # Temperature


def get_label_mask(y_true):
    """获取batch内相同label样本"""
    label = K.cast(y_true, 'int32')
    label_2 = K.reshape(label, (1, -1))
    mask = K.equal(label_2, label)
    mask = K.cast(mask, K.floatx())
    mask = mask * (1 - K.eye(K.shape(y_true)[0]))  # 排除对角线，即 i == j
    return mask


def SCL_loss(y_true, y_pred):
    label_mask = get_label_mask(y_true)
    y_pred = K.l2_normalize(y_pred, axis=1)  # 特征向量归一化
    similarities = K.dot(y_pred, K.transpose(y_pred))  # 相似矩阵
    similarities = similarities - K.eye(K.shape(y_pred)[0]) * 1e12  # 排除对角线,即 i == j
    similarities = similarities / T  # Temperature scale
    similarities = K.exp(similarities)  # exp
    sum_similarities = K.sum(similarities, axis=-1, keepdims=True)  # sum i != k
    scl = similarities / sum_similarities
    scl = K.log((scl + K.epsilon()))  # sum log
    scl = -K.sum(scl * label_mask, axis=1, keepdims=True) / (K.sum(label_mask, axis=1, keepdims=True) + K.epsilon())
    return K.mean(scl)