import numpy as np
import tensorflow as tf
from tensorflow.keras import backend as K


def gaussian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    n_samples = int(source.shape[0]) + int(target.shape[0])
    total = tf.concat([source, target], axis=0)

    total0 = tf.expand_dims(total, 0)
    total1 = tf.expand_dims(total, 1)
    L2_distance = tf.reduce_sum((total0 - total1) ** 2, axis=2)

    if fix_sigma:
        bandwidth = fix_sigma
    else:
        bandwidth = tf.reduce_sum(L2_distance) / (n_samples ** 2 - n_samples)
    bandwidth /= (kernel_mul ** (kernel_num // 2))
    bandwidth_list = [bandwidth * (kernel_mul ** i) for i in range(kernel_num)]

    kernel_val = [tf.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
    return tf.reduce_sum(kernel_val)


def JAN(source_list, target_list, kernel_muls=[2.0, 2.0], kernel_nums=[5, 1], fix_sigma_list=[None, 1.68]):
    batch_size = int(source_list[0].shape[0])
    layer_num = len(source_list)
    joint_kernels = None

    for i in range(layer_num):
        source = source_list[i]
        target = target_list[i]
        kernel_mul = kernel_muls[i]
        kernel_num = kernel_nums[i]
        fix_sigma = fix_sigma_list[i]

        kernels = gaussian_kernel(source, target, kernel_mul=kernel_mul, kernel_num=kernel_num, fix_sigma=fix_sigma)

        if joint_kernels is not None:
            joint_kernels = joint_kernels * kernels
        else:
            joint_kernels = kernels

    XX = joint_kernels[:batch_size, :batch_size]
    YY = joint_kernels[batch_size:, batch_size:]
    XY = joint_kernels[:batch_size, batch_size:]
    YX = joint_kernels[batch_size:, :batch_size]

    loss = tf.reduce_mean(XX + YY - XY - YX)
    return loss
