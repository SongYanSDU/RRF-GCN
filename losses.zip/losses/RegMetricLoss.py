import tensorflow as tf
from tensorflow.keras.layers import Layer


def reg_metric_loss(feature, label, sigma=1, w_leak=0.2, p=0.9, alpha=0):
    f2 = tf.reduce_sum(tf.square(feature), axis=1)
    f_dist = tf.sqrt(tf.maximum(f2[:, None] + f2[None, :] - 2 * tf.matmul(feature, feature, transpose_b=True), 0))
    label_0 = label[:, None] # label[:, None]：这是将 label 张量增加一个新的维度在最后一个轴。
    # 例如，如果 label 是一个形状为 [128] 的一维张量（128个元素），label[:, None] 将改变它的形状为 [128, 1]，即变成一个二维张量，其中每行包含原张量的一个元素。
    label_1 = label[None, :]
    l_dist = tf.abs(label_0 - label_1)
    w = tf.stop_gradient(tf.exp(-((l_dist / sigma) ** 2) / 2) + w_leak)
    diff = tf.abs(f_dist - l_dist)
    w_diff = w * diff

    mean_diff = tf.reduce_mean(w_diff)
    if alpha == 0:
        alpha = mean_diff
    else:
        alpha = p * alpha + (1 - p) * mean_diff
    mask = tf.greater(w_diff, alpha)
    nonz_num = tf.reduce_sum(tf.cast(mask, tf.float32))
    corr_w = tf.boolean_mask(w, mask)
    loss = tf.boolean_mask(w_diff, mask)
    return tf.reduce_sum(loss)/(tf.reduce_sum(corr_w) + 1e-9), nonz_num, alpha, mean_diff


'''这个程序定义了一个名为 RegMetricLoss 的自定义层，用于计算正则化的度量损失（Regularized Metric Loss），这种损失通常用于学习特征表示，使得相似标签的样本在特征空间中更接近。
程序的关键部分如下：
初始化：在 __init__ 方法中，初始化了一些参数，如 sigma（用于计算权重的高斯核参数）、w_leak（泄露权重，确保权重不为零）、和 p（用于计算动态阈值 alpha 的参数）。
前向传播（call 方法）：
计算特征距离：计算输入特征的两两距离。
计算标签距离：计算输入标签的两两绝对差异。
权重计算：根据标签距离和 sigma 计算权重 w，用于调节特征距离和标签距离之间的差异。
损失计算：使用过滤后的权重 w 和特征-标签距离差异来计算损失。
动态阈值更新：更新动态阈值 alpha，用于下一次损失计算。
输出：损失函数返回多个值，包括计算的损失、非零元素数量、当前的 alpha 值和平均差异。
这种损失函数在学习具有区分度的特征表示时很有用，尤其是在需要考虑特征空间中样本间关系的任务中，如度量学习和一些特定的分类任务。'''