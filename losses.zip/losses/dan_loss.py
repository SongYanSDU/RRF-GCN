import tensorflow as tf


def gaussian_kernel(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    n_samples = source.shape[0] + target.shape[0]
    total = tf.concat([source, target], axis=0)

    total0 = tf.expand_dims(total, 0)
    total1 = tf.expand_dims(total, 1)
    L2_distance = tf.reduce_sum((total0 - total1) ** 2, axis=2)

    if fix_sigma:
        bandwidth = fix_sigma
    else:
        bandwidth = tf.reduce_sum(L2_distance) / (n_samples ** 2 - n_samples)
    bandwidth /= (kernel_mul ** (kernel_num // 2))
    bandwidth_list = [bandwidth * (kernel_mul ** i) for i in range(kernel_num)]

    kernel_val = [tf.exp(-L2_distance / bandwidth_temp) for bandwidth_temp in bandwidth_list]
    return tf.reduce_sum(kernel_val, axis=0)


def DAN(source, target, kernel_mul=2.0, kernel_num=5, fix_sigma=None):
    batch_size = int(source.shape[0])
    kernels = gaussian_kernel(source, target, kernel_mul=kernel_mul, kernel_num=kernel_num, fix_sigma=fix_sigma)

    XX = kernels[:batch_size, :batch_size]
    YY = kernels[batch_size:, batch_size:]
    XY = kernels[:batch_size, batch_size:]
    YX = kernels[batch_size:, :batch_size]

    loss = tf.reduce_mean(XX + YY - XY - YX)
    return loss
