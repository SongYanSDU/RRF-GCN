import tensorflow as tf

'''# get feature embeddings
            feats = list()
            for domain_idx in range(self.ndomain):
                tmp_img = img_s[domain_idx]
                tmp_feat = self.G(tmp_img)
                feats.append(tmp_feat)'''
'''label_s = list()
            stop_iter = False
            for domain_idx in range(self.ndomain):
                tmp_img = data['S' + str(domain_idx + 1)].cuda()
                tmp_label = data['S' + str(domain_idx + 1) + '_label'].long().cuda()
                img_s.append(tmp_img)
                label_s.append(tmp_label)'''
# Update the global mean and adjacency matrix
# loss_local = self.update_statistics(feats, label_s)


def euclid_dist(x, y):
    x_sq = tf.reduce_mean(tf.square(x), axis=-1)
    x_sq_ = tf.expand_dims(x_sq, 1) * tf.ones((1, tf.shape(y)[0]))
    y_sq = tf.reduce_mean(tf.square(y), axis=-1)
    y_sq_ = tf.ones((tf.shape(x)[0], 1)) * tf.expand_dims(y_sq, 0)
    xy = tf.matmul(x, y, transpose_b=True) / tf.cast(tf.shape(x)[-1], tf.float32)
    dist = x_sq_ + y_sq_ - 2 * xy
    return dist

# Example usage
# x = tf.random.normal((batch_size, dim))
# y = tf.random.normal((batch_size, dim))
# distance = euclid_dist(x, y)


def update_statistics(feats, labels, ndomain, nclasses, mean):
    beta = 0.7
    sigma = 0.005
    epsilon = 1e-5
    curr_mean = list()
    num_labels = 0

    for domain_idx in range(ndomain):
        tmp_feat = feats[domain_idx]
        tmp_label = labels[domain_idx]
        num_labels += tf.shape(tmp_label)[0]

        onehot_label = tf.one_hot(tmp_label, nclasses)
        domain_feature = tf.expand_dims(tmp_feat, 1) * tf.expand_dims(onehot_label, -1)
        tmp_mean = tf.reduce_sum(domain_feature, axis=0) / (tf.expand_dims(tf.reduce_sum(onehot_label, axis=0), -1) + epsilon)
        curr_mean.append(tmp_mean)

    curr_mean = tf.concat(curr_mean, axis=0)
    curr_mask = tf.cast(tf.reduce_sum(curr_mean, axis=-1) != 0, tf.float32)
    curr_mask = tf.expand_dims(curr_mask, -1)
    # self.mean = torch.zeros(args.nclasses * self.ndomain, args.nfeat).cuda()

    mean = mean * (1 - curr_mask) + (mean * beta + curr_mean * (1 - beta)) * curr_mask
    curr_dist = euclid_dist(mean, mean)
    adj = tf.exp(-curr_dist / (2 * sigma ** 2))

    # Compute local relation alignment loss
    loss_local = tf.reduce_sum(tf.reduce_mean(tf.square((curr_mean - mean) * curr_mask), axis=-1)) / num_labels
    return mean, adj, loss_local


def local_loss(feats, labels):
    ndomain = 3
    nclasses = 3
    nfeat = 1024
    mean = tf.Variable(tf.zeros((ndomain * nclasses, nfeat)), trainable=False)
    mean, adj, loss_local = update_statistics(feats, labels, ndomain, nclasses, mean)
    return loss_local


def adj_loss(feats, labels):
    ndomain = 3
    nclasses = 3
    nfeat = 1024
    mean = tf.Variable(tf.zeros((ndomain * nclasses, nfeat)), trainable=False)
    mean, adj, loss_local = update_statistics(feats, labels, ndomain, nclasses, mean)
    adj_loss = tf.zeros(1)
    for i in range(ndomain):
        for j in range(ndomain):
            start_i = i * nclasses
            end_i = (i + 1) * nclasses
            start_j = j * nclasses
            end_j = (j + 1) * nclasses

            adj_ii = adj[start_i:end_i, start_i:end_i]
            adj_jj = adj[start_j:end_j, start_j:end_j]
            adj_ij = adj[start_i:end_i, start_j:end_j]

            adj_loss += tf.reduce_mean(tf.square(adj_ii - adj_jj))
            adj_loss += tf.reduce_mean(tf.square(adj_ij - adj_ii))
            adj_loss += tf.reduce_mean(tf.square(adj_ij - adj_jj))
    adj_loss = adj_loss / (ndomain * (ndomain - 1) / 2 * 3)
    return adj_loss

'''上面的程序段是用于实现一个图卷积网络（GCN）的一部分，具体来说是在模型中更新原型（mean features）和邻接矩阵，
并计算局部关系对齐损失（local relation alignment loss）。这个函数是针对多源域自适应设置中的，主要用于处理
来自不同域的特征和标签。其主要步骤和功能包括：

原型（Prototypes）更新：原型通常是不同类别或不同域中特征的平均值。这个函数对于每个域计算了特征的平均值（mean features）。
这些平均值可以被视为每个类别或每个域的代表性特征。

邻接矩阵（Adjacency Matrix）构建：在图卷积网络中，邻接矩阵用于表示节点（在这种情况下是不同的类别或域）之间的连接关系。
这个函数基于计算出的原型更新邻接矩阵，通常使用欧几里得距离和指数函数来计算节点间的相似度。

局部关系对齐损失计算：这一部分计算的损失旨在使原型向量更加紧密地对齐。
具体来说，它计算了更新后的原型与原始原型之间差异的平方和，这有助于在训练过程中保持类别或域内特征的一致性。

该函数是使用TensorFlow和Keras库编写的，适用于深度学习和神经网络的应用，尤其是在图卷积网络和域自适应领域。
通过这种方式，模型可以更好地理解和处理来自不同源的数据，特别是在涉及多个数据源时。'''