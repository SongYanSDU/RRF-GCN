import tensorflow as tf
from tensorflow.keras import backend as K


def covariance_loss(features1, features2):
    # 计算特征矩阵的均值
    mean1 = tf.reduce_mean(features1, axis=0, keepdims=True)
    mean2 = tf.reduce_mean(features2, axis=0, keepdims=True)

    # 计算去均值化的特
    features1_centered = features1 - mean1
    features2_centered = features2 - mean2
    # 计算协方差矩阵
    cov_matrix = tf.matmul(features1_centered, features2_centered, transpose_a=True)
    # 计算协方差矩阵的Frobenius范数
    loss = tf.norm(cov_matrix, ord='fro', axis=[-2, -1])
    return loss


def orthogonality_loss(features1, features2):
    # 计算特征矩阵的均值
    mean1 = tf.reduce_mean(features1, axis=0, keepdims=True)
    mean2 = tf.reduce_mean(features2, axis=0, keepdims=True)

    # 计算去均值化的特
    matrix1 = features1 - mean1
    matrix2 = features2 - mean2

    product = tf.matmul(matrix1, matrix2, transpose_b=True)
    identity_matrix = tf.eye(product.shape[0])
    loss = tf.norm(product - identity_matrix, ord='fro', axis=(-2, -1))
    return loss
