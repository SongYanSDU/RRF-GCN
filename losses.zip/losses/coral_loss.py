import tensorflow as tf


def CORAL(source, target):
    d = int(source.shape[1])  # feature dimension
    # Source covariance
    xm = tf.reduce_mean(source, axis=0, keepdims=True) - source
    xc = tf.matmul(xm, xm, transpose_a=True)

    # Target covariance
    xmt = tf.reduce_mean(target, axis=0, keepdims=True) - target
    xct = tf.matmul(xmt, xmt, transpose_a=True)

    # Frobenius norm between source and target
    loss = tf.reduce_mean(tf.square(xc - xct))
    loss = loss / (4 * d * d)

    return loss
