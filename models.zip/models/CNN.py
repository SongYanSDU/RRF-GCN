from tensorflow.keras.layers import (Input, Conv1D, BatchNormalization, ReLU, MaxPooling1D, GlobalMaxPooling1D, Dense,
                                     Dropout, Flatten, Reshape, Concatenate)
from tensorflow.keras.layers import Layer
from tensorflow.keras.models import Model
from tensorflow.keras.layers import MultiHeadAttention
from models.RFF import RandomFourierFeaturesLayer
len_segment = 4096
from models.RRF import RandomReceptiveField, CustomSelectionLayer
from models.spooling import StochasticPooling1D


def G_model_1(input_shape):
    inp = Input(shape=input_shape)
    x = inp
    x = Reshape((len_segment, 1))(x)
    x = Conv1D(128, 17, padding='same')(x)  # Adjust padding if needed
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    x = Conv1D(128, 17, padding='same')(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    '''x = Conv1D(128, 3, padding='same')(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(2)(x)'''

    out = x
    return Model(inputs=inp, outputs=out)


def G_model_2(input_shape):
    inp = Input(shape=input_shape)
    x = inp
    x = Reshape((len_segment, 1))(x)
    x = Conv1D(128, 17, padding='same')(x)  # Adjust padding if needed
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    x = Conv1D(128, 17, padding='same')(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    '''x = Conv1D(128, 3, padding='same')(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(2)(x)'''

    out = x
    return Model(inputs=inp, outputs=out)


def G_model_3(input_shape):
    inp = Input(shape=input_shape)
    x = inp
    x = Reshape((len_segment, 1))(x)
    x = Conv1D(128, 17, padding='same')(x)  # Adjust padding if needed
    # x = MixStyle()(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    x = Conv1D(128, 17, padding='same')(x)
    # x = MixStyle()(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(16)(x)

    '''x = Conv1D(128, 3, padding='same')(x)
    # x = MixStyle()(x)
    x = BatchNormalization()(x)
    x = ReLU()(x)
    x = MaxPooling1D(2)(x)'''

    out = x
    return Model(inputs=inp, outputs=out)


