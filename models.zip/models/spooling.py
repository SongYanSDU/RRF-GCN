import numpy as np
import random
import math
import tensorflow as tf
from tensorflow.keras.layers import Layer
from tensorflow.keras.layers import InputSpec
from tensorflow.keras import backend as K
from tensorflow.python.keras.utils import conv_utils

from tensorflow.python.framework import ops
from tensorflow.python.ops import gen_nn_ops

random.seed(91)


class StochasticPooling1D(Layer):
    def __init__(self, pool_size=2, padding='SAME', data_format='channels_last', **kwargs):
        super(StochasticPooling1D, self).__init__(**kwargs)

        self.pool_size = pool_size
        self.strides = pool_size
        self.padding = padding
        self.data_format = 'NWC' if data_format == 'channels_last' else 'NCW'
        self.input_spec = InputSpec(ndim=3)

    # ... rest of the class remains mostly the same ...

    def _tf_pooling_function(self, x, name=None):
        # Adjusted to handle 1D input
        input_shape = K.int_shape(x)
        b, l, channel = input_shape[0], input_shape[1], input_shape[2]

        pl = self.pool_size
        sl = self.strides

        # compute number of windows
        num_l = math.ceil(l / sl) if self.padding == 'SAME' else l // sl

        def _pool(inputs, is_train):

        # Adjusted to handle 1D input
        # ...

        # Adjusted to handle 1D input
            with ops.name_scope(name, "mod", [x]) as name:
                z = py_func(_pool,
                            [x, K.learning_phase()],
                            [K.tf.float32],
                            name=name,
                            grad=custom_grad)[0]
                z.set_shape((b, num_l, channel))

            return z

    def compute_output_shape(self, input_shape):
        # Adjusted to handle 1D input
        l = input_shape[1]
        sl = self.strides
        num_l = math.ceil(l / sl) if self.padding == 'SAME' else l // sl
        return (input_shape[0], num_l, input_shape[2])

    def call(self, inputs):
        output = self._tf_pooling_function(inputs)
        return output

    # ... get_config method remains the same ...
