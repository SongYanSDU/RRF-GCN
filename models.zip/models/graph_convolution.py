import math
import tensorflow as tf
from tensorflow.keras.layers import Layer
from tensorflow.keras import initializers


class GraphConvolution(Layer):
    def __init__(self, in_features, out_features, bias=True, **kwargs):
        super(GraphConvolution, self).__init__(**kwargs)
        self.in_features = in_features
        self.out_features = out_features
        self.bias = bias

        self.weight_initializer = initializers.RandomUniform(minval=-1/math.sqrt(out_features), maxval=1/math.sqrt(out_features))
        self.bias_initializer = initializers.Zeros() if bias else None

    def build(self, input_shape):
        self.weight = self.add_weight(shape=(self.in_features, self.out_features),
                                      initializer=self.weight_initializer,
                                      trainable=True,
                                      name='weight')

        if self.bias:
            self.bias = self.add_weight(shape=(self.out_features,),
                                        initializer=self.bias_initializer,
                                        trainable=True,
                                        name='bias')
        super(GraphConvolution, self).build(input_shape)

    def call(self, inputs, **kwargs):
        input, adj = inputs
        support = tf.matmul(input, self.weight)
        output = tf.matmul(adj, support)

        if self.bias is not None:
            output += self.bias

        return output

    def get_config(self):
        config = super(GraphConvolution, self).get_config()
        config.update({'in_features': self.in_features,
                       'out_features': self.out_features,
                       'bias': self.bias})
        return config

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'
