import keras
import tensorflow as tf
from keras.layers import Layer
import numpy as np


class RandomFourierFeaturesLayer(tf.keras.layers.Layer):
    def __init__(self, num_f=1, sigma=1.0, sum=True, **kwargs):
        super(RandomFourierFeaturesLayer, self).__init__(**kwargs)
        self.num_f = num_f
        self.sigma = sigma
        self.sum = sum

    def build(self, input_shape):
        input_dim = input_shape[-1]
        output_dim = input_shape[-1]
        self.kernel = self.add_weight(name='kernel',
                                      shape=(input_dim, output_dim),
                                      initializer='he_normal',
                                      trainable=False)
        super(RandomFourierFeaturesLayer, self).build(input_shape)

    def call(self, x):
        # Compute Random Fourier Features
        Z = tf.sqrt(2.0 / self.num_f)
        mid = tf.matmul(x, self.kernel)
        mid -= tf.reduce_min(mid, axis=1, keepdims=True)
        mid /= tf.reduce_max(mid, axis=1, keepdims=True)
        mid *= np.pi / 2.0

        if self.sum:
            Z = Z * (tf.cos(mid) + tf.sin(mid))
        else:
            Z = Z * tf.concat([tf.cos(mid), tf.sin(mid)], axis=-1)
        return Z

    def get_config(self):
        config = super(RandomFourierFeaturesLayer, self).get_config()
        config.update({
            'num_f': self.num_f,
            'sigma': self.sigma,
            'sum': self.sum
        })
        return config


'''class RandomFourierFeatures(Layer):
    def __init__(self, scale=1.0, **kwargs):
        # self.output_dim = output_dim
        self.scale = scale
        super(RandomFourierFeatures, self).__init__(**kwargs)

    def build(self, input_shape):
        input_dim = input_shape[-1]
        output_dim = input_shape[-1]
        self.kernel = self.add_weight(name='kernel',
                                      shape=(input_dim, output_dim),
                                      initializer='he_normal',
                                      trainable=False)
        super(RandomFourierFeatures, self).build(input_shape)

    def call(self, x):
        rff = tf.math.cos(tf.matmul(x, self.kernel) * self.scale)
        return rff'''


'''class RandomFourierFeatures(Layer):
    def __init__(self, scale=1.0, **kwargs):
        # self.output_dim = output_dim
        self.scale = scale
        super(RandomFourierFeatures, self).__init__(**kwargs)

    def build(self, input_shape):
        input_dim = input_shape[-1]  # 获取最后一个维度 M
        output_dim = input_shape[-1]
        self.kernel = self.add_weight(name='kernel',
                                      shape=(input_dim, output_dim),
                                      initializer='uniform',
                                      trainable=False)
        super(RandomFourierFeatures, self).build(input_shape)

    def call(self, x):
        # 应用随机傅里叶特征映射
        # 使用 tf.map_fn 来处理每一个 N x M 的矩阵
        # 如果 x 是一个形状为 [a, b] 的张量, 而 y 是一个形状为 [b, c] 的张量, 那么它们可以进行矩阵乘法, 并且结果张量的形状将是[a, c]
        rff = tf.map_fn(lambda xi: tf.math.cos(tf.matmul(xi, self.kernel) * self.scale), x)  # 在数学上等同于矩阵的点积或内积
        return rff'''
