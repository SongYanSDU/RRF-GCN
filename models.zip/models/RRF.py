import tensorflow as tf
from tensorflow.keras.layers import Layer
import tensorflow.keras.backend as K
import numpy as np


class RandomReceptiveField(Layer):
    def __init__(self, size, min, max, **kwargs):
        super(RandomReceptiveField, self).__init__(**kwargs)
        self.size = size  # 感受野的大小
        self.min = min
        self.max = max

    def call(self, inputs):
        # 随机选择开始索引
        start_index = tf.random.uniform(shape=[], minval=self.min,
                                        maxval=self.max,
                                        dtype=tf.int32)
        # 选择感受野区域
        selected = inputs[:, start_index:start_index + self.size, :]
        return selected

    def compute_output_shape(self, input_shape):
        # 输出形状为 (batch_size, size, input_shape[-1])
        return (input_shape[0], self.size, input_shape[-1])


class RandomIndexField(Layer):
    def __init__(self, size, **kwargs):
        super(RandomIndexField, self).__init__(**kwargs)
        self.size = size  # 感受野的大小

    def call(self, inputs):
        # 随机选择开始索引
        max = tf.shape(inputs)[1]
        # 生成随机索引，从32中随机选择8个不同的索引
        indices = tf.random.shuffle(tf.range(max))[:8]
        indices = tf.sort(indices)
        tensor_selected = tf.gather(inputs, indices, axis=1)
        return tensor_selected

    def compute_output_shape(self, input_shape):
        # 输出形状为 (batch_size, size, input_shape[-1])
        return (input_shape[0], self.size, input_shape[-1])


class CustomSelectionLayer(Layer):
    def __init__(self, num_groups=8, **kwargs):
        super(CustomSelectionLayer, self).__init__(**kwargs)
        self.num_groups = num_groups

    def call(self, inputs):
        # 输入尺寸: batch_size × 16 × 128
        # 将输入划分为8组，每组2个特征
        grouped = K.reshape(inputs, (-1, self.num_groups, 2, inputs.shape[2]))

        # 定义一个函数，用于从每个样本的每组中随机选择一个特征
        def select_from_group(group):
            idxs = tf.random.uniform(shape=(self.num_groups,), maxval=2, dtype=tf.int32)
            return tf.gather(group, idxs, axis=1, batch_dims=1)

        # 对每个样本应用选择函数
        selected = tf.map_fn(select_from_group, grouped, dtype=tf.float32)
        # print(selected.shape)
        # 重塑为 batch_size × 8 × 128
        return K.reshape(selected, shape=(-1, self.num_groups, inputs.shape[2]))

    def compute_output_shape(self, input_shape):
        return (input_shape[0], self.num_groups, input_shape[2])