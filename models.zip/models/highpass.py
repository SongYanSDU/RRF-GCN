from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D
from tensorflow.keras.initializers import Initializer
import numpy as np


class HighPassFilterInitializer1D(Initializer):
    def __call__(self, shape, dtype=None):
        # 确保 shape 参数是正确的卷积核形状 (kernel_size, input_channels, output_channels)
        kernel_size, input_channels, output_channels = shape

        # 创建一个简单的一维高通滤波器核
        kernel = np.array([-1, 2, -1], dtype='float32')
        kernel = np.expand_dims(kernel, axis=-1)
        kernel = np.expand_dims(kernel, axis=-1)

        # 重复 kernel 以匹配 input_channels 和 output_channels
        kernel = np.repeat(kernel, input_channels, axis=1)
        kernel = np.repeat(kernel, output_channels, axis=2)
        return kernel

